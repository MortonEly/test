// ==UserScript==
// @name         屏蔽b站(bilibili)播放页面中右侧相关视频推荐与直播广告
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  屏蔽b站播放页面中右侧推荐 (去掉代码中的第24行与30行注释符可进一步屏蔽up主与弹幕信息）
// @author       simplelife
// @match        *://www.bilibili.com/video/*
// @grant        none
// @require      https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

    //已登陆
    $('.recommend-list-v1').hide();

    //未登陆
    $('.next-play').hide();
    $('.rec-list').hide();

    /*——————去掉该行注释符即可屏蔽up主与弹幕信息——————
    //up主信息屏蔽
    $('.u-face').hide();
    $('.up-info_right').hide();
    //弹幕信息屏蔽
    $('.danmaku-box').hide();
    */ //——————去掉该行注释符即可屏蔽up主与弹幕信息——————

    setTimeout(function(){
        $('.lazy-img').hide();
    }, 1000);
    setTimeout(function(){
        $('.lazy-img').hide();
        $('.pl__info').hide();
        $('.pl__head').hide();
        $('.ad-report').hide();
        $('.ad-floor-exp').hide();
        //未登陆
        $('.next-play').hide();
        $('.rec-footer').hide();
        $('.live_recommand_report').hide();
         //右侧分隔线等其它内容屏蔽
        $('.split-line').hide();
        $('.pl__card').hide();
    }, 3000);
    setTimeout(function(){
        $('.lazy-img').hide();
        $('.pl__info').hide();
        $('.pl__head').hide();
        $('.ad-report').hide();
        $('.ad-floor-exp').hide();
        //未登陆
        $('.next-play').hide();
        $('.rec-footer').hide();
        $('.live_recommand_report').hide();
         //右侧分隔线等其它内容屏蔽
        $('.split-line').hide();
        $('.pl__card').hide();
    }, 5000);

})();