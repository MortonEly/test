// ==UserScript==
// @name         Remove Ads
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  屏蔽百度热搜
// @author       baidu.com
// @match        https://www.baidu.com/*
// @grant        none
// ==/UserScript==


(function() {
  'use strict';

  function removeElement(elements){
    console.info(elements);
    if(elements !== null && elements !== undefined){
      if(elements.length > 0){
        var element = elements[0]
        element.parentNode.removeChild(element)
      }
    }
  }

  function removeByClassName(cName){
    var elements = document.getElementsByClassName(cName);
    removeElement(elements);
  }

  function removeById(eId){
    var element = document.getElementById(eId)
    var elements = null;
    if(element !== null){
      elements = []
      elements.push(element);
    }
    removeElement(elements);

  }

  function check(){
    console.info("start");
    removeByClassName("FYB_RD");
    removeByClassName("opr-recommends-merge-content");
    removeById("s-hotsearch-wrapper");
  }

  window.onload = () => {
    setInterval(check,500)
    // q[0].style.display="none";
    // document.getElementById("su").value = "Search";
  };
})();