// ==UserScript==
// @name         油猴中文網去複製後綴
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://bbs.tampermonkey.net.cn/*
// @icon         https://www.google.com/s2/favicons?domain=tampermonkey.net.cn
// @grant        none
// ==/UserScript==

let oldcopy=window.setCopy
window.setCopy=function(text, msg){
    return oldcopy.call(this,text.replace('\n(出处: 油猴中文网)\n',""), msg)
}