// ==UserScript==
// @name        去除 bilibili 专栏防复制,小尾巴
// @description 去除 bilibili 专栏防复制, 去除小尾巴
// @namespace   userjs.cn
// @match       *://www.bilibili.com/read/*
// @grant       none
// @version     1.1
// @author      zio
// @run-at document-end
// ==/UserScript==

;(function() {
  var $ = document.querySelector.bind(document)
  var $$ = document.querySelectorAll.bind(document)
  window.onload = function() {
      var unreprint = $('.unable-reprint')
      if (unreprint) {
        unreprint.style.userSelect = 'auto'
        unreprint.style['-webkit-user-select'] = 'auto'
      }

      // var article = $('div.article-holder')
      
      $$('*').forEach(item=> item.oncopy = e => e.stopPropagation())
  }
})()
