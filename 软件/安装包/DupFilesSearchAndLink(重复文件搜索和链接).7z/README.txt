Duplicate Files Search & Link (aka Duplicate & Same Files Searcher)
===================================

This application searches duplicate files and NTFS hard links to file.
This application allows not only to delete duplicate files or to move them to another location, but to replace duplicates with NTFS hard links as well (unique!).
Remember: you delete, move or replace files on your own risk and your own responsibility! Author is not responsible for any possible loss of your data or system corruption due to work of this application! It is not recommended to replace files with NTFS hard links if you don't understand really how they work. 
A hard link is the file system representation of a file by which more than one path references a single file in the same volume. Because hard links are only directory entries for a file, when an application modifies a file through any hard link, other hard links will reflect all changes in file content.

You must have the .NET Framework 4.7.2 (or newer) installed in order to use Duplicate Files Search & Link. 
The .NET Framework 4.7.2+ is already pre-installed on Windows 10 version 1803 and later.
You can also install .NET Desktop Runtime 5.0 https://dotnet.microsoft.com/download/dotnet-core/5.0/runtime/ to run executable file DuplicateSearcherCore.exe built for .NET 5.0 platform.

Duplicate Files Search & Link supports the following command-line parameters:
	-s "Path1;[Path2;][Path3;]": search file duplicates in paths separated by ';'.
		Example: DuplicateSearcher.exe -s "D:\Photos1;D:\Photos2;"
			 or  DuplicateSearcher.exe -s "D:/Photos1;D:/Photos2;"

	-profile "<ProfileName>": select profile name to be used for search started from command line. 
		If the parameter is missing or given profile name doesn't exist, settings from default profile "Default" will be used.
		Example: DuplicateSearcher.exe -s "D:\Photos1;D:\Photos2;" -profile "Photos".
			 or  DuplicateSearcher.exe -s "D:/Photos1;D:/Photos2;" -profile "Photos".
				
This application is free for non-commercial use, but if you find it useful for you, you can donate some money to the developer to support the further development of this program.

(c) 2008-2022 Yury Malich, St. Petersburg, Russia.
http://duplicatesearcher.net
http://malich.ru/duplicate_searcher
http://malich.org/duplicate_searcher

e-mail: <duplicate.searcher@gmail.com>, <duplicate.searcher@yandex.com>

Certain icons used in the Duplicate Files Search & Link user interface are from or adapted from those in the "Sky Light (Basic)" free icon set, http://www.ReadyIcons.com.
This software also uses 
- freeware taglib-sharp Library, https://github.com/mono/taglib-sharp, covered by GNU LGPL
- freeware SharpShell Library, http://sharpshell.codeplex.com/, covered by The MIT License (MIT)
