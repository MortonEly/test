# QTTabBar_zh-CN

> * QTTabBar 官方简体中文语言包：https://raw.githubusercontent.com/indiff/qttabbar/master/Lng_QTTabBar_zh.xml
> * 软件下载: http://qttabbar.wikidot.com/qttabbar

### 先安装  *1038包*  再UPdate *1042包*，上传两个语言包均**基于1036版本，兼容1038及以上版本**！

  1. 因为内置的语言包下载功能基于**Google Docs**，中国境内访问困难，故提供此仓库作为备份及下载点，便于大家使用。
  2. 亦欢迎指正翻译错误或提出建议。请使用右侧的Issues（问题）功能提出。

## QTTabBar最新的开源release版本下载地址：https://github.com/indiff/qttabbar/releases
